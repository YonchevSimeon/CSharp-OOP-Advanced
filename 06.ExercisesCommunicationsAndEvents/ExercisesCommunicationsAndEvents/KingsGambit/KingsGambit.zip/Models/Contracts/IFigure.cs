﻿namespace KingsGambit.Models.Contracts
{
    public interface IFigure
    {
         string Name { get; }
    }
}
