﻿namespace WorkForce.Models.Contracts
{
    public interface INameable
    {
        string Name { get; }
    }
}
