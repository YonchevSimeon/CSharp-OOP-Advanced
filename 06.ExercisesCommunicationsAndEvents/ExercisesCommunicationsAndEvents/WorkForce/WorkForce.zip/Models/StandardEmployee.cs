﻿namespace WorkForce.Models
{
    
    public class StandardEmployee : Employee
    {
        public StandardEmployee(string name)
            : base(name, 40) { }
    }
}
