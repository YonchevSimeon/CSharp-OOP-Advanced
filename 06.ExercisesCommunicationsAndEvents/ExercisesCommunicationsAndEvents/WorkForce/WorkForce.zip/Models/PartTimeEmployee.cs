﻿namespace WorkForce.Models
{
    public class PartTimeEmployee : Employee
    {
        public PartTimeEmployee(string name)
            : base(name, 20) { }
    }
}
