﻿namespace InfernoInfinity.Models.Enums
{
    public enum WeaponType
    {
        Axe,
        Sword,
        Knife
    }
}
