﻿namespace InfernoInfinity.Models.Enums
{
    public enum Quality
    {
        Common = 1,
        Uncommon = 2,
        Rare = 3,
        Epic = 5
    }
}
