﻿namespace InfernoInfinity.Models.Contracts
{
    public interface IRunnable
    {
        void Run();
    }
}
