﻿namespace LoggerExercise.Enums
{
    public enum ErrorType
    {
        INFO,
        WARNING,
        ERROR,
        CRITICAL,
        FATAL
    }
}
