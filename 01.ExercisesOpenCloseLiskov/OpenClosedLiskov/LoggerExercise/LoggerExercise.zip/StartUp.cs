﻿namespace LoggerExercise
{
    using LoggerExercise.Directory;

    class StartUp
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
