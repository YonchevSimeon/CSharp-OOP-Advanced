﻿namespace ExtendedDatabase.Models.Interfaces
{
    public interface IPerson
    {
        string Username { get; }
        long Id { get; }
    }
}
