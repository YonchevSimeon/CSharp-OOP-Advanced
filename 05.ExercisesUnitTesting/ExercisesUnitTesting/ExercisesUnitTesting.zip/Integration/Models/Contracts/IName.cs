﻿namespace Integration.Models.Contracts
{
    public interface IName
    {
        string Name { get; }
    }
}
