﻿using DateTimeNow.Models;
using System;

namespace DateTimeNow
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
